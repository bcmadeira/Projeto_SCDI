# Frontend - Sistema de Controle de Doações Institucional (SCDI)

Este diretório contém todos os arquivos frontend do Sistema de Controle de Doações Institucional, criados baseados nos designs do Figma.

## 📁 Estrutura de Pastas

```
frontend/
├── css/
│   └── common.css          # Estilos comuns utilizados em todas as telas
├── js/
│   ├── login.js           # Lógica da tela de login
│   ├── doador-cadastro.js # Lógica do cadastro de doador
│   ├── instituicao-cadastro.js # Lógica do cadastro de instituição
│   ├── relatorio.js       # Lógica da tela de relatórios
│   ├── minhas-campanhas.js # Lógica da tela de campanhas
│   ├── criar-campanha.js  # Lógica para criar/editar campanhas
│   └── dashboard.js       # Lógica do dashboard principal
├── views/
│   ├── login.html         # Tela de login
│   ├── welcome.html       # Tela de boas-vindas
│   ├── doador-cadastro.html # Formulário de cadastro de doador
│   ├── instituicao-cadastro.html # Formulário de cadastro de instituição
│   ├── relatorio.html     # Tela de relatórios de doações
│   ├── minhas-campanhas.html # Tela de gerenciamento de campanhas
│   ├── criar-campanha.html # Tela para criar/editar campanhas
│   └── dashboard.html     # Dashboard principal
└── assets/
    └── images/            # Imagens e ícones do sistema
```

## 🎨 Telas Implementadas

### 1. **Login** (`login.html`)
- Formulário de autenticação
- Campos: Email e Senha
- Link para cadastro
- Validações JavaScript

### 2. **Boas-vindas** (`welcome.html`)
- Tela inicial para novos usuários
- Opções: "Quero Doar" e "Quero Criar Doações"
- Design limpo e intuitivo

### 3. **Cadastro de Doador** (`doador-cadastro.html`)
- Formulário completo com campos pessoais
- Máscaras para CPF, telefone e CEP
- Validação de CPF
- Layout responsivo

### 4. **Cadastro de Instituição** (`instituicao-cadastro.html`)
- Formulário específico para instituições
- Campos: CNPJ, endereço, descrição
- Integração com API ViaCEP
- Validação de CNPJ

### 5. **Relatório de Doações** (`relatorio.html`)
- Tabela de doações com filtros
- Estatísticas em cards
- Exportação para CSV
- Status das doações (Pendente, Confirmada, Entregue)

### 6. **Minhas Campanhas** (`minhas-campanhas.html`)
- Grade de campanhas em cards
- Filtros por status e busca
- Ações: Ver, Editar, Pausar/Reativar
- Indicadores de progresso

### 7. **Criar/Editar Campanha** (`criar-campanha.html`)
- Formulário completo para campanhas
- Calendário customizado para seleção de datas
- Validações de período
- Categorias e configurações

### 8. **Dashboard** (`dashboard.html`)
- Visão geral com estatísticas
- Gráficos interativos (Chart.js)
- Atividades recentes
- Ações rápidas

## 🚀 Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Estilos modernos com Grid e Flexbox
- **JavaScript (ES6+)**: Interatividade e validações
- **Bootstrap 5**: Framework CSS para responsividade
- **Bootstrap Icons**: Ícones consistentes
- **Chart.js**: Gráficos interativos no dashboard

## 📱 Características

### Responsividade
- Design mobile-first
- Breakpoints para tablet e desktop
- Grid adaptativo

### Acessibilidade
- Labels apropriados nos formulários
- Navegação por teclado
- Contraste adequado

### UX/UI
- Interface intuitiva
- Feedback visual nas ações
- Estados de loading e validação
- Animações suaves

## 🔧 Funcionalidades JavaScript

### Validações
- CPF e CNPJ
- Email
- Campos obrigatórios
- Datas (período válido)

### Máscaras
- CPF: 000.000.000-00
- CNPJ: 00.000.000/0000-00
- Telefone: (00) 00000-0000
- CEP: 00000-000

### Interatividade
- Calendário customizado
- Filtros em tempo real
- Exportação de dados
- Gráficos interativos

## 🎯 Integração com Backend

As telas estão preparadas para integração com o backend Laravel através de:

- Formulários com `action` e `method` apropriados
- Campos com `name` attributes correspondentes aos models
- JavaScript preparado para receber respostas AJAX
- Estrutura de dados consistente

## 📋 Próximos Passos

1. **Integração**: Conectar forms com controllers Laravel
2. **Autenticação**: Implementar sistema de sessões
3. **API**: Criar endpoints para dados dinâmicos
4. **Notificações**: Sistema de alertas em tempo real
5. **Upload**: Funcionalidade para imagens das campanhas

## 🎨 Design System

### Cores Principais
- **Verde**: #28a745 (Ações primárias)
- **Azul**: #17a2b8 (Ações secundárias)
- **Amarelo**: #ffc107 (Alertas)
- **Cinza**: #f8f9fa (Backgrounds)

### Tipografia
- **Fonte**: Segoe UI, Tahoma, Geneva, Verdana, sans-serif
- **Tamanhos**: 12px-36px (responsivo)

### Componentes
- Cards com sombra sutil
- Botões com hover effects
- Inputs com focus states
- Grid responsivo

---

**Desenvolvido seguindo os designs do Figma e as melhores práticas de frontend.**